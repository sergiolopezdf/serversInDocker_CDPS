// C
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <netdb.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>

// C++
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

int main () {
    for (int a = 0; a <= 255; a++) {
	ostringstream o;
	o << "192.168.1." << a;

	struct in_addr ad;
	inet_aton (o.str().c_str(), &ad);

	unsigned index = 0;
	for (char *cp = (char*) &ad;
	     unsigned(cp - (char*)&ad) < sizeof(struct in_addr);
	     cp++) {
	    index += *cp;
	    index %= 60;
	    //cout << " " << "byte: " << hex << *cp
	    // << ", index: " << index << "\n";
	}

	cout << inet_ntoa(ad) <<  ": " << dec << index << "\n";
    }

    return (0);
}
	
