#include "httpbuffer"

string Httpbuffer::paramvalue (string c) {
    PROFILE("Httpheader::paramvalue");

    string uri = requesturi();
    string match = c;
    if (match[match.size() - 1] != '=')
	match += '=';
    string ret = "";
    size_t pos = uri.find(match);
    if (pos != string::npos) {
	pos += match.size();
	for (char ch = uri[pos];
	     pos < uri.size() && ch != '&' && ch != '?';
	     ch = uri[++pos])
	    ret += ch;
    }
    msg("Param value '" << c << "' : '" << ret << "'\n");
    return ret;
}
