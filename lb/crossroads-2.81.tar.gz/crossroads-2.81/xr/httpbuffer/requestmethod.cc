#include "httpbuffer"

Httpbuffer::RequestMethod Httpbuffer::requestmethod() {
    PROFILE("Httpheader::requestmethod");

    if (bufsz() >= 3 && !strncmp(bufdata(), "GET", 3))
	return (m_get);

    return (m_other);
}
	
