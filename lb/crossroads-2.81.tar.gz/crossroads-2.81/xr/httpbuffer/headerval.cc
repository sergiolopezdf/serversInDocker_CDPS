#include "httpbuffer"

string Httpbuffer::headerval (string const &var) {
    PROFILE("Httpbuffer::headerval");
    
    if (!headersreceived())
	return ("");
    
    string myvar = var;
    if (myvar[myvar.size() - 1] != ':')
	myvar += ":";

    unsigned int start;
    if ( (!(start = strfind(myvar.c_str()))) ||
	 (start >= bodystart) )
	return ("");

    start += myvar.size();
    for (char ch = charat(start); ch && isspace(ch); ch = charat(++start))
	;
    string ret;
    for (char ch = charat(start); ch && ch != '\r' && ch != '\n';
	 ch = charat(++start))
	ret += ch;

    debugmsg ("Header " + myvar + " '" + ret + "'\n");
    return (ret);
}
