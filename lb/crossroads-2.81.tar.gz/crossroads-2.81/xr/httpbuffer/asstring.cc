#include "httpbuffer"

string Httpbuffer::as_string() const {
    string ret = "";

    for (unsigned i = 0; i < bufsz(); i++)
	ret += charat(i);

    return ret;
}
