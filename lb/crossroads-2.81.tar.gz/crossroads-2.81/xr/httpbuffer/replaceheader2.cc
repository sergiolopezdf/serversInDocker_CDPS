#include "httpbuffer"

void Httpbuffer::replaceheader(string const &var, string const &val) {
    PROFILE("Httpbuffer::replacehader(string,string)");

    if (!headersreceived())
	return;

    debugmsg("Attempting to replace header " << var << " with " << val << '\n');

    unsigned off = findheader(var);
    debugmsg("Header [" << var << "] occurs at position " << off << '\n');
    if (off) {
	unsigned nl = charfind('\n', off);
	if (nl)
	    removeat(off, nl - off + 1);
	setheader(var, val);
    }
}
