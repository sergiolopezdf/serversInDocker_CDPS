#include "httpbuffer"

Httpbuffer::Httpbuffer(): bodystart(0), first_line("") {
    PROFILE("Httpbuffer::Httpbuffer");
}
