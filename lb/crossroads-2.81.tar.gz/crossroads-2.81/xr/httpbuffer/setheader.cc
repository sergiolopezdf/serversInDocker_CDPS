#include "httpbuffer"

void Httpbuffer::setheader (string const &var, string const &val) {
    PROFILE("Httpbuffer::setheader");
    
    if (!headersreceived())
	return;
	
    string myvar = var;
    
    if (myvar[myvar.size() - 1] != ':')
	myvar += ':';

    // Find position beyond first \n
    unsigned i;
    if (! (i = charfind('\n')) )
	return;

    // Poke in the header.
    string h;
    h = myvar + ' ' + val + "\r\n";
    insertat(i + 1, h.c_str());
}
