#include "httpbuffer"

void Httpbuffer::replaceheader(string const &h) {
    PROFILE("Httpbuffer::replacehader(string)");

    unsigned i;
    for (i = 0; i < h.size(); i++)
	if (h[i] == ':') {
	    string var = h.substr(0, i);
	    i++;
	    while (isspace(h[i]))
		i++;
	    string val = h.substr(i);
	    replaceheader(var, val);
	    return;
	}
}
