#include "httpbuffer"

void Httpbuffer::addheader (string const &h) {
    PROFILE("Httpbuffer::addheader(string)");

    if (!headersreceived())
	return;
    
    unsigned i;
    for (i = 0; i < h.size(); i++)
	if (h[i] == ':') {
	    string var = h.substr(0, i);
	    i++;
	    while (isspace(h[i]))
		i++;
	    string val = h.substr(i);
	    addheader (var, val);
	    return;
	}
}
