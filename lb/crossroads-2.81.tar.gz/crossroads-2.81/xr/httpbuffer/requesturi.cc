#include "httpbuffer"

string Httpbuffer::requesturi() {
    PROFILE("Httpbuffer:requesturi");
    
    vector<string> parts = str2parts (firstline(), ' ');
    return (parts.size() >= 2 ? parts[1] : "");
}
