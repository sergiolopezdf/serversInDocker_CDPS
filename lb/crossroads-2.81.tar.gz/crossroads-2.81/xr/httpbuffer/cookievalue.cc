#include "httpbuffer"

string Httpbuffer::cookievalue (string c) {
    PROFILE("Httpheader::cookievalue");
    
    string cval = headerval ("Cookie");
    string match = c;
    if (match[match.size() - 1] != '=')
	match += '=';
    string ret = "";
    size_t pos = cval.find(match);
    if (pos != string::npos) {
	pos += match.size();
	for (char ch = cval[pos];
	     pos < cval.size() && ch != ';' && ch != ',' && ch;
	     ch = cval[++pos]) {
	    ret += ch;
	}
    }
    msg("Cookie value '" << c << "' : '" << ret << "'\n");
    return (ret);
}
