#include "httpbuffer"

bool Httpbuffer::setversion (char v) {
    PROFILE("Httpbuffer::setversion");

    // No first line? Nothing to do yet.
    unsigned croff = charfind('\n');
    if (!croff)
	return false;

    // Find the HTTP/1.x header
    unsigned stroff = strfind("HTTP/1.");
    if (!stroff || stroff > croff)
	return false;
    
    // Poke in the new version.
    return setchar(stroff + 7, v);
}
