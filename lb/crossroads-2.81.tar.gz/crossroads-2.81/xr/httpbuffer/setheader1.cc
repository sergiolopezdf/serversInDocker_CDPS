#include "httpbuffer"

void Httpbuffer::setheader (string const &h) {
    PROFILE("Httpbuffer::setheader(string)");
    
    unsigned i;
    for (i = 0; i < h.size(); i++)
	if (h[i] == ':') {
	    string var = h.substr(0, i);
	    i++;
	    while (isspace(h[i]))
		i++;
	    string val = h.substr(i);
	    setheader (var, val);
	}
}
