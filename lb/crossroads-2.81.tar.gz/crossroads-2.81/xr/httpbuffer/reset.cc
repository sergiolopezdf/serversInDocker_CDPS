#include "httpbuffer"

void Httpbuffer::reset() {
    first_line = "";
    bodystart = 0;
    Netbuffer::reset();
}
