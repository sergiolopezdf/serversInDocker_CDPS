#include "httpbuffer"

void Httpbuffer::addheader (string const &var, string const &val) {
    PROFILE("Httpbuffer::addheader(string,string)");

    if (!headersreceived())
	return;
    
    string old = headerval(var);
    if (old.size()) {
	old += ", " + val;
	setheader(var, old);
    } else
	setheader (var, val);
}
