#include "httpbuffer"

bool Httpbuffer::headersreceived() {
    PROFILE("Httpbuffer::headersreceived");
    
    if (bodystart)
	return (true);

    unsigned off;
    if ( (off = strfind("\r\n\r\n")) > 0 ) {
	bodystart = off + 4;
	return (true);
    }
    if ( (off = strfind("\n\n")) > 0 ) {
	bodystart = off + 2;
	return (true);
    }
    return (false);
}
