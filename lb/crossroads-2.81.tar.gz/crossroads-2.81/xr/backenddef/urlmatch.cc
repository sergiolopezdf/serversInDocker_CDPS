#include "backenddef"

void BackendDef::urlmatch (string const &s) {
    PROFILE("BackendDef::urlmatch");

    url_match = (s == "" ? "." : s);
    if (regcomp (&url_regex, url_match.c_str(),
		 REG_EXTENDED | REG_ICASE | REG_NOSUB))
	throw Error("Url match specifier '" +
		    url_match + "' isn't a valid regular expression");
}
