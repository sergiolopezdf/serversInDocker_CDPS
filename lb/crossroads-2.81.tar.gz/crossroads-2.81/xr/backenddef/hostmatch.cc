#include "backenddef"

void BackendDef::hostmatch (string const &s) {
    PROFILE("BackendDef::hostmatch");

    host_match = (s == "" ? "." : s);
    if (regcomp (&host_regex, host_match.c_str(),
		 REG_EXTENDED | REG_ICASE | REG_NOSUB))
	throw Error("Host match specifier '" +
		    host_match + "' isn't a valid regular expression");
}
