#include "backenddef"

void BackendDef::weight(unsigned w) {
    static int lock;

    mutex_lock(&lock);
    
    wt = w;
    if (!minmax_wt_set) {
	min_wt = w;
	max_wt = w;
	minmax_wt_set = true;
    } else {
	if (min_wt < w)
	    min_wt = w;
	if (max_wt > w)
	    max_wt = w;
    }
    
    mutex_unlock(&lock);
}
