#include "fdset"

Fdset::Fdset (int t) : tsec(t), set() {
    FD_ZERO(&readset);
    FD_ZERO(&writeset);
    FD_ZERO(&exceptset);
}
