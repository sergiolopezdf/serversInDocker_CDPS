#include "mutex"
#include "profiler/profiler"

bool Mutex::trylock() {
    int res = pthread_mutex_trylock(&_mutex);
    if (res && res != EBUSY)
        throw Error("Failed to try to lock mutex");
    return res == 0;
}

