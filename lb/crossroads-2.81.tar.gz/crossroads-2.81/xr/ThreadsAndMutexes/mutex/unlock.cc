#include "mutex"
#include "error/error"
#include "profiler/profiler"

void Mutex::unlock() {
    if (pthread_mutex_unlock(&_mutex))
        throw Error("Failed to unlock mutex");
}
