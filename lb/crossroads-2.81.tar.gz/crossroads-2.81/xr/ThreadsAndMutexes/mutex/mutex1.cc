#include "mutex"

Mutex::Mutex() {
    if (pthread_mutex_init(&_mutex, 0))
	throw Error("Failed to initialize mutex");
}
