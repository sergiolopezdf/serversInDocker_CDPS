#include "mutex"
#include "profiler/profiler"

void Mutex::lock() {
    if (pthread_mutex_lock(&_mutex))
        throw Error("Failed to lock mutex");
}

