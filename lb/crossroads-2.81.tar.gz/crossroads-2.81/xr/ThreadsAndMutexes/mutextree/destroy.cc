#include "mutextree"

void MutexTree::destroy() {
    delete _root;
    _root = 0;
}
