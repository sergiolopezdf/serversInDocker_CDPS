#include "mutextree"

MutexTree const &MutexTree::operator=(MutexTree const &other) {
    if (this != &other) {
        destroy();
        copy(other);
    }
    return *this;
}
