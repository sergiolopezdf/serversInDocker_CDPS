#include "mutextree"

void MutexTree::copy(MutexTree const &other) {
#   ifdef DEBUG
    debugmsg("Mutex: WARNING - copy invoked\n");
#   endif
    
    _treelock = other._treelock;
    _root = new MutexNode(other._root);
}
