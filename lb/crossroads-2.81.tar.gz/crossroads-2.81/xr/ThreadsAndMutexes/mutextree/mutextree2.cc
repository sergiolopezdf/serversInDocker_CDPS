#include "mutextree"

MutexTree::MutexTree(MutexTree const &other) {
#   ifdef DEBUG
    debugmsg("Mutex: copy constructor (this=" << this << ")\n");
#   endif    
    copy(other);
}
