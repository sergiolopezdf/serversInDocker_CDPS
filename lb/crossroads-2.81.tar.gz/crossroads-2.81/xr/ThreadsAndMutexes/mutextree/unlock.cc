#include "mutextree"

void MutexTree::unlock(void *o) {
#   ifdef DEBUG
    debugmsg("Mutex: unlocking object: " << o << '\n');
#   endif    
    nodeunlock(o, _root);
#   ifdef DEBUG
    debugmsg("Mutex: object " << o << " unlocked\n");
#   endif    
}
