#include "mutextree"

void MutexTree::unlocktree() {
#   ifdef DEBUG
    debugmsg("Mutex: unlocking tree\n");
#   endif    
    _treelock.unlock();
#   ifdef DEBUG
    debugmsg("Mutex: tree unlocked\n");
#   endif    
}
