#include "mutextree"

MutexTree::~MutexTree() {
#   ifdef DEBUG
    debugmsg("Mutex: destroying " << this << "\n");
#   endif    
    destroy();
}
