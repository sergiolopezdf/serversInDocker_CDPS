#include "mutextree"

void MutexTree::lock(void *o) {
#   ifdef DEBUG
    debugmsg("Mutex: locking object: " << o <<
	     " (this=" << this << ", root=" << _root << ")\n");
#   endif    
    locktree();
    _root = nodelock(o, _root);
    unlocktree();
#   ifdef DEBUG
    debugmsg("Mutex: object " << o << " locked\n");
#   endif    
}
