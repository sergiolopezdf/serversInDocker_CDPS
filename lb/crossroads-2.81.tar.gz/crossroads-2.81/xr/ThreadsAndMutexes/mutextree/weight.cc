#include "mutextree"

int MutexTree::weight() const {
    return _root ? _root->weight() : 0;
}
