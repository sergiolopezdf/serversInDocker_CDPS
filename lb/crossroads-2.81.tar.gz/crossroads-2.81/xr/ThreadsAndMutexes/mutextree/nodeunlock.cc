#include "mutextree"

void MutexTree::nodeunlock(void *o, MutexNode *start) {
    if (!start)
        return;

    if (start->obj() == o)
        start->unlock();
    else if (start->obj() < o)
        nodeunlock(o, start->left());
    else
        nodeunlock(o, start->right());
}
