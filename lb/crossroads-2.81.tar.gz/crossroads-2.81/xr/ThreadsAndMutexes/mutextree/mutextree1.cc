#include "mutextree"

MutexTree::MutexTree(): _root(0), _treelock() {
#   ifdef DEBUG
    debugmsg("Mutex: constructed (this=" << this << ", root=" << _root
	     << ")\n");
#   endif    
}
