#include "mutextree"

int MutexTree::balance() const {
    return _root ? _root->balance() : 0;
}
