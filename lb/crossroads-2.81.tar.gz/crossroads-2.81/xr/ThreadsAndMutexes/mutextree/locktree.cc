#include "mutextree"

void MutexTree::locktree() {
#   ifdef DEBUG
    debugmsg("Mutex: locking tree\n");
#   endif    
    _treelock.lock();
#   ifdef DEBUG
    debugmsg("Mutex: tree locked\n");
#   endif    
}
