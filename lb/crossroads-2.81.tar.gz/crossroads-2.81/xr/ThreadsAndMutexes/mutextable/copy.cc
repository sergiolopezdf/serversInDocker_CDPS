#include "mutextable"

void MutexTable::copy(MutexTable const &other) {
    _size = other.size();
    _table = new MutexTree* [_size];
    for (unsigned i = 0; i < _size; i++)
        _table[i] = new MutexTree(*(other._table[i]));
}
