#include "mutextable"

MutexTable::MutexTable(unsigned sz): _size(sz) {
    debugmsg("Initializing mutex table with " << sz << " slots");
    _table = new MutexTree* [sz];
    for (unsigned i = 0; i < sz; i++)
        _table[i] = new MutexTree;
}

