#include "mutextable"

MutexTable::MutexTable(MutexTable const &other) {
    copy(other);
}
