#include "mutextable"

void MutexTable::destroy() {
    for (unsigned i = 0; i < _size; i++)
        delete _table[i];
    delete _table;
}
