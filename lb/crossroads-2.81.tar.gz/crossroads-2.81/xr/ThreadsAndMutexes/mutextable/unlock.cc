#include "mutextable"

void MutexTable::unlock(void *obj) {
    _table[hash(obj)]->unlock(obj);
}
