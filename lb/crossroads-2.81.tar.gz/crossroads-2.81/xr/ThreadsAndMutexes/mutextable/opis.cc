#include "mutextable"

MutexTable const &MutexTable::operator=(MutexTable const &other) {
    if (this != &other) {
        destroy();
        copy(other);
    }
    return *this;
}
