#include "mutextable"

int MutexTable::balance(unsigned i) const {
    return i < size() ? _table[i]->weight() : 0;
}
