#include "mutextable"

void MutexTable::lock(void *obj) {
    _table[hash(obj)]->lock(obj);
}
