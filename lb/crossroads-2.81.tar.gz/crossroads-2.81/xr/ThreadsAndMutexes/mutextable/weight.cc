#include "mutextable"

int MutexTable::weight(unsigned i) const {
    return i < size() ? _table[i]->weight() : 0;
}
