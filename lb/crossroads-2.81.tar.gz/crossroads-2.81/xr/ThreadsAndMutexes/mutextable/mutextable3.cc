#include "mutextable"

MutexTable::~MutexTable() {
    destroy();
}
