#include "thread"

// Dummy incase the derived class doesn't define one
void Thread::execute() {
}
