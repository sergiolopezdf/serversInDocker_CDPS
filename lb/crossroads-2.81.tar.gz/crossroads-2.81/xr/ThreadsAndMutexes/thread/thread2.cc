#include "thread"

Thread::~Thread() {
}
