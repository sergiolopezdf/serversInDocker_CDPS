#include "threadlist"

void Threadlist::backendfd(Socket &f) {
    th_map[pthread_self()].backendfd(f.fd());
}
