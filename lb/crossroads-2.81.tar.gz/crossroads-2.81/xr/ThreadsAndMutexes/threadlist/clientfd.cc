#include "threadlist"

void Threadlist::clientfd(Socket &f) {
    th_map[pthread_self()].clientfd(f.fd());
}
