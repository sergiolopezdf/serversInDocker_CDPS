#include "threadlist"

Threadmap Threadlist::th_map;

void Threadlist::enregister() {
    Threadinfo n;
    mutex_lock(&th_map);
    th_map[pthread_self()] = n;
    mutex_unlock(&th_map);
}
