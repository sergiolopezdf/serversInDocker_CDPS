#include "threadlist"

void Threadlist::desc(string const &s) {
    th_map[pthread_self()].desc(s);
}
