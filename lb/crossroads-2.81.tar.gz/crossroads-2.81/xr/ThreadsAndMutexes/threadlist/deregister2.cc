#include "threadlist"

void Threadlist::deregister() {
    deregister(pthread_self());
}

