#include "threadlist"

Threadinfo Threadlist::info(pthread_t id) {
    return th_map[id];
}
