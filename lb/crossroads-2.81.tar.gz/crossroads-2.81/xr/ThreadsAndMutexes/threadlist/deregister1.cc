#include "threadlist"

void Threadlist::deregister(pthread_t id) {
    mutex_lock(&th_map);
    th_map.erase(id);
    mutex_unlock(&th_map);
}
