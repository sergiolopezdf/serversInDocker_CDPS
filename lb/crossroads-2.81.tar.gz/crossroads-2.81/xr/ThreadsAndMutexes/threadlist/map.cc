#include "threadlist"

Threadmap &Threadlist::map() {
    return th_map;
}
