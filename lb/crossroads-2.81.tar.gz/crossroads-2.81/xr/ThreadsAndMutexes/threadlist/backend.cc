#include "threadlist"

void Threadlist::backend(int b) {
    th_map[pthread_self()].backend(b);
}
