#include "threadlist"

void Threadlist::clientip(struct in_addr adr) {
    th_map[pthread_self()].clientip(adr);
}
