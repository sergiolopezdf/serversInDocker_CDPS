#include "mutexnode"

int MutexNode::weight() const {
    int w = 1;
    if (left())
        w += left()->weight();
    if (right())
        w += right()->weight();
    return w;
}
