#include "mutexnode"

MutexNode::MutexNode(MutexNode const &other) {
    copy(other);
}
