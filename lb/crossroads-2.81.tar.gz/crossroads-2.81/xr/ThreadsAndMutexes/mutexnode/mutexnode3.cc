#include "mutexnode"

MutexNode::~MutexNode() {
    destroy();
}
