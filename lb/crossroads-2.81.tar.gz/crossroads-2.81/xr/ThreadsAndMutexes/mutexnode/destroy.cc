#include "mutexnode"

void MutexNode::destroy() {
    delete _left;
    delete _right;
}
