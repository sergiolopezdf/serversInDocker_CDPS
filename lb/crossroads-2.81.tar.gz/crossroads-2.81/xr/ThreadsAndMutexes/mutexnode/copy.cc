#include "mutexnode"

void MutexNode::copy(MutexNode const &other) {
    mutex(other.mutex());
    obj(other.obj());
    left(other.left() ? new MutexNode(*(other.left())) : 0);
    right(other.right() ? new MutexNode(*(other.right())) : 0);
}
