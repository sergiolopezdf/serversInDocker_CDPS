#include "mutexnode"

MutexNode::MutexNode(void *o): _mutex(), _obj(o), _left(0), _right(0) {
}

