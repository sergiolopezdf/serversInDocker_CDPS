#include "mutexnode"

MutexNode const &MutexNode::operator=(MutexNode const &other) {
    if (this != &other) {
        destroy();
        copy(other);
    }
    return *this;
}
