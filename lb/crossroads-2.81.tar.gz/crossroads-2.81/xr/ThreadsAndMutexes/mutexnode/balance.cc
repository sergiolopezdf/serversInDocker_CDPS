#include "mutexnode"

int MutexNode::balance() const {
    int lw = left() ? left()->weight() : 0;
    int rw = right() ? right()->weight() : 0;
    return lw - rw;
}
