#include "error"

Error::Error (int i) {
    ostringstream o;
    o << i;
    desc = o.str();
}
