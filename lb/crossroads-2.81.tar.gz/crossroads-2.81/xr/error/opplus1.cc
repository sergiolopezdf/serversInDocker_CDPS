#include "error"

Error &Error::operator+ (Error const &other) {
    desc += other.desc;
    return (*this);
}
