#include "error"

Error &Error::operator+ (string const &s) {
    desc += s;
    return (*this);
}
