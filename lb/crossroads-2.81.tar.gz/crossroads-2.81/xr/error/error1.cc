#include "error"

Error::Error (string s): desc(s) {
}
