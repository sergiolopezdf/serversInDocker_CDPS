#include "error"

Error &Error::operator+ (int i) {
    ostringstream o;

    o << i;
    desc += o.str();
    
    return (*this);
}
