#include "backendcheck"

string BackendCheck::setting() const {
    ostringstream o;
    
    if (check_type == c_external)
	o << "external:" << extprog;
    else {
	if (check_type == c_connect)
	    o << "connect:";
	else
	    o << "get:";
	if (srv != "")
	    o << srv;
	o << ':';
	if (prt)
	    o << prt;
	if (check_type == c_get)
	    o << geturi;
    }
    return o.str();
}
