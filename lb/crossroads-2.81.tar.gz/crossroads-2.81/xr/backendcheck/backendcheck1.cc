#include "backendcheck"

BackendCheck::BackendCheck() : check_type(c_connect), srv(""), prt(0),
			       geturi(""), extprog("")
{
}
