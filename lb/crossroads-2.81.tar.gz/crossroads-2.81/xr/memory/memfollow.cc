#include "memory"

void Memory::mem_follow(bool b) {
    s_follow = b;
}
