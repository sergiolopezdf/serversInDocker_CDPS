#include "memory"

void Memory::operator delete[](void *ptr) {
    free(ptr);
}
