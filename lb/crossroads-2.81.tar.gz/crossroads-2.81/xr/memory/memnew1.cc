#include "memory"

void *Memory::operator new[](size_t sz) {
    return malloc(sz);
}
