#include "memory"

Memory::MemoryLog Memory::s_memlog;
bool Memory::s_follow;
