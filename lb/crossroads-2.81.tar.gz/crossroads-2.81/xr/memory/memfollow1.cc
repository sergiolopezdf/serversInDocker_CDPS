#include "memory"

bool Memory::mem_follow() {
    return s_follow;
}
