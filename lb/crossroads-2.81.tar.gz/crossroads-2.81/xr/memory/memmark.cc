#include "memory"

void Memory::mem_mark(string const &desc) {
    MemoryEntry ent = { 0, 0, "MARK " + desc };
    static int lock;
    
    mutex_lock(&lock);
    s_memlog.push_back(ent);
    mutex_unlock(&lock);
}
