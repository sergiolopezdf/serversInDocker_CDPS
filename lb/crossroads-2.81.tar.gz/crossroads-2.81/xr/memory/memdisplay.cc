#include "memory"

void Memory::mem_display() {
    static int lock;
    
    mutex_lock(&lock);
    for (unsigned i = 0; i < s_memlog.size(); i++) {
	MemoryEntry ent = s_memlog[i];
	mutex_lock(&cout);
	cout << "Memory::mem_display " << ent.ptr << ' ' << ent.sz
	     << ' ' << ent.desc << '\n';
	mutex_unlock(&cout);
    }
    mutex_unlock(&lock);
}
