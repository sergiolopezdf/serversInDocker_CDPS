#include "balancer"

Balancer::Balancer () :
    server_fd(), request_nr(0), backends(),
    term(false), rep(false), rest(false), webinterface(0) {
}
