#include "balancer"

void Balancer::addbackend (BackendDef const &b) {
    Backend newb (b);
    addbackend(newb);
}
