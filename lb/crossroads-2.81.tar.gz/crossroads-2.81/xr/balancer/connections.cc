#include "balancer"

unsigned Balancer::connections() {
    unsigned ret = 0;
    
    for (unsigned i = 0; i < nbackends(); i++)
	ret += backend(i).connections();
    return (ret);
}
