# firstav.pl - sample "first available" dispatching algorithm,
# implemented as an external Perl program

#!/usr/bin/perl

use strict;

print STDERR ("firstav.pl: Invocation: @ARGV\n");
my $n = shift (@ARGV);
for my $i (0..$n - 1) {
    my $addr = shift (@ARGV);
    my $av   = shift (@ARGV);
    my $conn = shift (@ARGV);
    print STDERR ("firstav.pl: $i: backend at $addr, $av, $conn connections\n");
    if ($av eq 'available') {
	print ("$i\n");
	exit (0);
    }
}
print STDERR ("firstav.pl: Nothing available!\n");
exit (1);
