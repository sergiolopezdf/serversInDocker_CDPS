#include "profiler"

FILE *Profiler::outf;

Profiler::Profiler (char const *f): timestamp() {
    fname = f;
}
    
