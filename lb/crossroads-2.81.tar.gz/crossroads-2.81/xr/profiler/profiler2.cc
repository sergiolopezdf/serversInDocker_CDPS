#include "profiler"

Profiler::~Profiler() {
    if (!outf)
	outf = fopen ("/tmp/xr-prof.txt", "w");
    if (outf)
	fprintf (outf, "%s %s %g\n",
		 timestamp.desc().c_str(), fname, timestamp.elapsed());
}
