#include "backend"

string Backend::upstr() const {
    return (up() ? "up" : "down");
}
