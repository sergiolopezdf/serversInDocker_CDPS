#include "backend"

void Backend::addbytes (unsigned n) {
    static int lock;
    mutex_lock(&lock);
    bytes_served += n;
    mutex_unlock (&lock);
}
