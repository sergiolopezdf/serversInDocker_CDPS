#include "backend"

void Backend::markconnecterror() {
    debugmsg("Logging connection error on back end " << description() << '\n');

    static int lock;
    
    mutex_lock(&lock);
    nconnerr++;
    mutex_unlock(&lock);
}
