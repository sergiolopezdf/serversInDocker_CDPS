#include "backend"

string Backend::description() const {
    ostringstream o;
    o << server() << ":" << port();
    return (o.str());
}
