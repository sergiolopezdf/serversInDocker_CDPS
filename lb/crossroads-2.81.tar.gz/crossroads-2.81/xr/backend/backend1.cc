#include "backend"

Backend::Backend () :
    bdef(), islive(true), isup(true), clsocket(),
    nconn(0), totconn(0), nconnerr(0),
    bytes_served(0),
    loadaverage(0.1), dnsentry(), index(-1) {
}
