#include "backend"

void Backend::startconnection() {
    static int lock;

    mutex_lock (&lock);
    nconn++;
    totconn++;
    mutex_unlock (&lock);
}
