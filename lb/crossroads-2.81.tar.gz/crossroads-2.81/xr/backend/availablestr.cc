#include "backend"

string Backend::availablestr() const {
    return (available() ? "available" : "unavailable");
}
