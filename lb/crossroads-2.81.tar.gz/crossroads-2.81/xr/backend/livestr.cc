#include "backend"

string Backend::livestr() const {
    return (live() ? "alive" : "dead");
}
