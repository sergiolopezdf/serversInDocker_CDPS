#include "backend"

void Backend::endconnection() {
    static int lock;
    
    mutex_lock(&lock);
    nconn--;
    mutex_unlock (&lock);
}
