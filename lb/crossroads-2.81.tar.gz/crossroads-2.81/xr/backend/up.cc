#include "backend"

void Backend::up (bool state) {
    PROFILE("Backend::up");

    static int lock;
    
    mutex_lock (&lock);
    bool oldstate = isup;
    isup = state;
    mutex_unlock (&lock);
    
    if (oldstate != state)
	msg("Marking back end " << description() << " as " << upstr() << "\n");
}
