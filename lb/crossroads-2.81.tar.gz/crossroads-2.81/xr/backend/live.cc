#include "backend"

void Backend::live (bool state) {
    PROFILE("Backend::live");

    static int lock;

    mutex_lock(&lock);
    islive = state;
    mutex_unlock(&lock);
}
