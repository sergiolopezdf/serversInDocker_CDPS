#include "sys"

#ifndef HAVE_INET_ATON
int inet_aton (char const *name, struct in_addr *addr) {
    in_addr_t a = inet_addr (name); 
    addr->s_addr = a; 
    return a != (in_addr_t)-1; 
}
#endif
