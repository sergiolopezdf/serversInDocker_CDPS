#include "sys"

int maxtimeout(int a, int b) {
    if (!a)
	return b;
    if (!b)
	return a;
    return a < b ? a : b;
}
