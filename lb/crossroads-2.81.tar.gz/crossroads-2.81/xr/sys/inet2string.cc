#include "sys/sys"
#include "ThreadsAndMutexes/mutex/mutex"

string inet2string(struct in_addr in) {
    string ret;

    mutex_lock((void*)inet_ntoa);
    ret = inet_ntoa(in);
    mutex_unlock((void*)inet_ntoa);

    return ret;
}
