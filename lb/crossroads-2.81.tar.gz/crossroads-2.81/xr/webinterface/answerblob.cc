#include "webinterface"

void Webinterface::answer_blob (string const &blob) {
    ostringstream cl;
    cl << blob.size();
    string resp = static_cast<string>
       ("HTTP/1.0 200 OK\r\n") +
	"Content-Type: text/xml\r\n"
	"Connection: close\r\n"
	"Content-Length: " + cl.str() + "\r\n"
	"\r\n" +
	blob;
    Netbuffer buf(resp);
    buf.netwrite(cfd, config.client_write_timeout());
}
