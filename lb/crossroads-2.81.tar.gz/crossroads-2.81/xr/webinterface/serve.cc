#include "webinterface"

void Webinterface::serve() {
    debugmsg("Webinterface serving request on client fd " << cfd.fd() << '\n');

    Httpbuffer clientrequest;
    clientrequest.netread(cfd, config.client_read_timeout());
    msg("Webinterface request: " << clientrequest.firstline() << '\n');

    answer(clientrequest);
}
