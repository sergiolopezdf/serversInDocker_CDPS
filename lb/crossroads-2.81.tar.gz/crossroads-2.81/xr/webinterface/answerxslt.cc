#include "webinterface"
#include "../build/status.xslt.h"

void Webinterface::answer_xslt() {
    answer_blob (XSLT);
}
