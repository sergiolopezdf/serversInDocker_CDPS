#include "webinterface"

Webinterface::~Webinterface() {
    msg("Stopping web interface\n");
}
