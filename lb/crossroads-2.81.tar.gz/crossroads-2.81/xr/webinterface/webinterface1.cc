#include "webinterface"

Webinterface::Webinterface(): cfd(), sfd() {
}
