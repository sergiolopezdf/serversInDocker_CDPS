#include "config"

int Config::setinteger (string s) const {
    int ret;
    if (sscanf (s.c_str(), "%d", &ret) < 1)
	throw Error("Bad numeric specifier in '" + s + ": not a number");
    return (ret);
}
