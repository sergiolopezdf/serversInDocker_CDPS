#include "config"

void Config::webinterface_auth(string const &s) {
    // Make sure there is a ':' delimiter in the parameter
    if (s.length() > 0 && s.find_first_of(':') == string::npos)
	throw Error("Bad web interface authentication parameter, "
		    "format must be username:password");

    web_auth = s;
}
    
