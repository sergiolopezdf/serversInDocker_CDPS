#include "config"

void Config::deleteallow(unsigned index) {
    if (index >= allowlist.size())
	throw Error("Index out of range, cannot delete allow-from");
    allowlist.erase(allowlist.begin() + index,
		    allowlist.begin() + index + 1);
}

