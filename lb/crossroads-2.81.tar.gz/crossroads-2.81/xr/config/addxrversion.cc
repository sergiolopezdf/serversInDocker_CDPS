#include "config"

void Config::addxrversion(bool b) {
    int lock;
    
    mutex_lock (&lock);
    add_xr_version = b;
    mutex_unlock (&lock);
}
