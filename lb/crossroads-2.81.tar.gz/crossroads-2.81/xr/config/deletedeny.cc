#include "config"

void Config::deletedeny(unsigned index) {
    if (index >= denylist.size())
	throw Error("Index out of range, cannot delete deny-from");
    denylist.erase(denylist.begin() + index,
		   denylist.begin() + index + 1);
}

