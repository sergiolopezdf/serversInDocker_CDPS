#include "config"

bool Config::verbose_flag = false;
int Config::lport = 10000;
Servertype Config::styp;
string Config::sip = "0";
vector<BackendDef> Config::blist;
Dispatchmode Config::dmode;
unsigned Config::c_timeout = 30;
unsigned Config::c_write_timeout = 5;
unsigned Config::b_timeout = 30;
unsigned Config::b_write_timeout = 3;
unsigned Config::wakeup = 5;
unsigned Config::checkup = 0;
unsigned Config::bufsize = 2048;
bool Config::foreground_mode = false;
bool Config::add_xr_version = false;
bool Config::debug_flag = false;
bool Config::add_x_forwarded_for = false;
bool Config::sticky_http = false;
bool Config::replace_host_header = false;
unsigned Config::max_conn = 0;
string Config::external_algorithm = "";
string Config::pid_file = "";
bool Config::prefix_timestamp = false;
vector<string> Config::serverheaders;
vector<struct in_addr> Config::allowlist;
vector<struct in_addr> Config::denylist;
bool Config::fast_close = false;
int Config::ipstore_timeout;
bool Config::use_webinterface = false;
string Config::webinterface_ip;
int Config::webinterface_port;
string Config::webinterface_name;
string Config::web_auth;
string Config::dump_dir;
unsigned Config::soft_maxconnrate = 0;
unsigned Config::hard_maxconnrate = 0;
unsigned Config::defer_time = 500000;
unsigned Config::connrate_timeinterval = 1;
unsigned Config::quit_after = 0;
string Config::soft_maxconn_excess_prog = "";
string Config::hard_maxconn_excess_prog = "";
unsigned Config::dns_cache_timeout = 3600;
string Config::on_start = "";
string Config::on_end = "";
string Config::on_fail = "";
bool Config::remove_reservations = false;
char **Config::org_argv = 0;

Config::Config () {
}
