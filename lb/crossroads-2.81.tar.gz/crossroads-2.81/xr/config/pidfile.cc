#include "config"

void Config::pidfile (string const &p) {
    int lock;
    
    mutex_lock (&lock);
    pid_file = p;
    mutex_unlock (&lock);
}
