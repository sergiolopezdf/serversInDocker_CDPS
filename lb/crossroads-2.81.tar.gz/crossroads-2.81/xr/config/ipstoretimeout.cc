#include "config"

void Config::ipstoretimeout (int t) {
    int lock;
    
    mutex_lock (&lock);
    ipstore_timeout = t;
    mutex_unlock (&lock);
}
