#include "config"

void Config::addallow (string a) {
    struct in_addr in;
    if (!inet_aton (a.c_str(), &in))
	throw Error("Bad allow-from specfier '" + a + "'");
    allowlist.push_back (in);
}
