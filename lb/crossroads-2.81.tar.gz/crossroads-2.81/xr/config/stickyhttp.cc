#include "config"

void Config::stickyhttp (bool b) {
    int lock;
    
    mutex_lock (&lock);
    sticky_http = b;
    mutex_unlock (&lock);
}
