#include "config"

void Config::changedeny (string &a, unsigned index) {
    if (index >= denylist.size())
	throw Error("No such deny-from specifier");

    struct in_addr in;
    if (!inet_aton (a.c_str(), &in))
	throw Error("Bad deny-from specfier '" + a + "'");
    denylist[index] = (in);
}
    
