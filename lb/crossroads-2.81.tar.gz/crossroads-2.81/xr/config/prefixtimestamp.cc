#include "config"

void Config::prefixtimestamp(bool b) {
    int lock;
    
    mutex_lock (&lock);
    prefix_timestamp = b;
    mutex_unlock (&lock);
}
