#include "config"

void Config::addserverheader (string const &s) {
    int lock;
    
    mutex_lock (&lock);
    serverheaders.push_back (s);
    mutex_unlock (&lock);
}
