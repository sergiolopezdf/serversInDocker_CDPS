#include "config"

void Config::fastclose(bool b) {
    int lock;
    
    mutex_lock (&lock);
    fast_close = b;
    mutex_unlock (&lock);
}
