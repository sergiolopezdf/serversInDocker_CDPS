#include "config"

void Config::maxconn (unsigned m) {
    int lock;
    
    mutex_lock (&lock);
    max_conn = m;
    mutex_unlock (&lock);
}
