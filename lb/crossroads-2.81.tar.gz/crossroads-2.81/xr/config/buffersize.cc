#include "config"

void Config::buffersize(unsigned b) {
    int lock;
    
    mutex_lock (&lock);
    bufsize = b;
    mutex_unlock (&lock);
}
