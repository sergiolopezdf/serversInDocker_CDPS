#include "config"

void Config::changeserverheader (unsigned i, string const &s) {
    int lock;
    
    mutex_lock (&lock);
    serverheaders[i] = s;
    mutex_unlock (&lock);
}
