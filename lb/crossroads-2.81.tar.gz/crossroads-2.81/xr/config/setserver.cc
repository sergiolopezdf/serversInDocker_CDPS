#include "config"

void Config::setserver (string str) {
    // Split into 3 parts
    vector<string> parts = str2parts (str, ':');
    if (parts.size() != 3)
	throw Error("Bad server specifier, expected: TYPE:IPADDRESS:PORT");

    // Store type, IP and port
    styp.type (parts[0]);
    sip = parts[1];
    lport = setinteger (parts[2]);
}
