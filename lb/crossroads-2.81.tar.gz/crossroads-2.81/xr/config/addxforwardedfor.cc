#include "config"

void Config::addxforwardedfor(bool b) {
    int lock;
    
    mutex_lock (&lock);
    add_x_forwarded_for = b;
    mutex_unlock (&lock);
}
