#include "config"

void Config::changeallow (string &a, unsigned index) {
    if (index >= allowlist.size())
	throw Error("No such allow-from specifier");

    struct in_addr in;
    if (!inet_aton (a.c_str(), &in))
	throw Error("Bad allow-from specfier '" + a + "'");
    allowlist[index] = (in);
}
    
