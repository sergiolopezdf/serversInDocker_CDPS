#include "config"

void Config::removeserverheader (unsigned i) {
    int lock;
    
    mutex_lock (&lock);
    serverheaders.erase (serverheaders.begin() + i,
			 serverheaders.begin() + i + 1);
    mutex_unlock (&lock);
}
