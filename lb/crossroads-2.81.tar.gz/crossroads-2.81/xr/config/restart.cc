#include "config"

void Config::restart() {
	for (int i = 0; org_argv[i]; i++)
	    cout << "Arg " << i << ": " << org_argv[i] << '\n';
	execvp("xr", org_argv);
	ostringstream o;
	o << "Failed to restart: errno=" << errno << ", "
	  << strerror(errno);
	throw Error(o.str());
}
