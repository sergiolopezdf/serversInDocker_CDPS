#include "config"

void Config::adddeny (string d) {
    struct in_addr in;
    if (!inet_aton (d.c_str(), &in))
	throw Error("Bad deny-from specfier '" + d + "'");
    denylist.push_back (in);
}
