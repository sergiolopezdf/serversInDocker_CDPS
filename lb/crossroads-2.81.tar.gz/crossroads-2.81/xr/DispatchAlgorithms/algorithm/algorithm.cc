#include "algorithm"

Algorithm::~Algorithm() {
}
