#include "firstactive"

unsigned Firstactive::target(struct in_addr clientip,
			     BackendVector &targetlist) {
    if (config.debug()) {
	debugmsg("First-active algorithm: " << targetlist.size() <<
		 " back end(s) to consider\n");
	for (unsigned int i = 0; i < targetlist.size(); i++)
	    debugmsg("  Considering back end " << targetlist[i] <<
		     " which is " <<
		     balancer.backend(targetlist[i]).description() << '\n');
    }
    if (targetlist.size() == 0)
	throw Error("First-active algorithm: no available back ends");
    return (targetlist[0]);
}
    
