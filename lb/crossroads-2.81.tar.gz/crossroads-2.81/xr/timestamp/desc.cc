#include "timestamp"

string Timestamp::desc() const {
    struct tm *tmp = localtime(&tv.tv_sec);
    char buf[80];
    sprintf (buf, "%4.4d-%2.2d-%2.2d %2.2d:%2.2d:%2.2d,%3.3d",
             tmp->tm_year + 1900, tmp->tm_mon + 1, tmp->tm_mday,
             tmp->tm_hour, tmp->tm_min, tmp->tm_sec,
             int(tv.tv_usec / 1000));
    return buf;
}          
