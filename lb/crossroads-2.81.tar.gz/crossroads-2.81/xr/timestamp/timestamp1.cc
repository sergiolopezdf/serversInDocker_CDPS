#include "timestamp"

Timestamp::Timestamp() {
    gettimeofday(&tv, 0);
}
