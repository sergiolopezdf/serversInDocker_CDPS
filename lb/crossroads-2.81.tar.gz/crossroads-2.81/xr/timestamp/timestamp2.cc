#include "timestamp"

Timestamp::Timestamp(int sec_since_epoch) {
    tv.tv_sec = sec_since_epoch;
    tv.tv_usec = 0;
}
