#include "timestamp"

double Timestamp::elapsed() const {
    struct timeval end;
    gettimeofday(&end, 0);
    double usec = 
	( ((double)end.tv_sec * 1000000 + end.tv_usec) -
          ((double)tv.tv_sec * 1000000 + tv.tv_usec) );
    return usec / 1000000;
}
