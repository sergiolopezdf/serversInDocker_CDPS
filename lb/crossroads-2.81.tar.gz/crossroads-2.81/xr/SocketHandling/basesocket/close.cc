#include "basesocket"

void Basesocket::close() {
    if (_initialized && _fd > 0) {
	debugmsg("Shutting down socket " << _fd << '\n');
	if (config.fastclose()) {
	    struct linger l;
	    l.l_onoff = 1;
	    l.l_linger = 2;
	    setsockopt (_fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
	}
	shutdown(_fd, SHUT_RDWR);
	::close(_fd);
	_fd = -1;
    }
}
