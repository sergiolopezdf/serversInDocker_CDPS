#include "basesocket"

Basesocket::~Basesocket() {
    close();
}
