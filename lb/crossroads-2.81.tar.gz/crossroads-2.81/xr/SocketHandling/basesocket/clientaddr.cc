#include "basesocket"

struct sockaddr_in Basesocket::clientaddr() {
    return _clientaddr;
}
