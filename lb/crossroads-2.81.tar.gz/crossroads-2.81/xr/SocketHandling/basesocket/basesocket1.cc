#include "basesocket"

Basesocket::Basesocket(): _fd(-1), _initialized(false) {
}
