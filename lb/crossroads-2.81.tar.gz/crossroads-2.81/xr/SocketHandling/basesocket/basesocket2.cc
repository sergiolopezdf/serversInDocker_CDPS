#include "basesocket"

Basesocket::Basesocket(int f): _fd(f), _initialized(true) {
}
