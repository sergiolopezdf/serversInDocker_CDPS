#include "basesocket"

bool Basesocket::operator==(Basesocket const &other) const {
    return _fd == other._fd;
}
