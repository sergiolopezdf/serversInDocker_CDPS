#include "basesocket"

int Basesocket::fd() {
    if (_initialized)
	return _fd;

    _initialized = true;
    if ( (_fd = socket(PF_INET, SOCK_STREAM, 0)) < 0 )
	throw Error(string("Failed to create socket: ") +
		    strerror(errno));
    
    debugmsg("Socket " << _fd << " created\n");

    return _fd;
}
