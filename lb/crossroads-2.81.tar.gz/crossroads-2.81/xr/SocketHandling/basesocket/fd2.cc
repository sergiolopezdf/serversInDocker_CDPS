#include "basesocket"

void Basesocket::fd(int f) {
    _fd = f;
    _initialized = true;
}
