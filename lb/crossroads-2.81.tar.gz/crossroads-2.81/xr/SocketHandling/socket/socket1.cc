#include "socket"

Socket::Socket() {
    _refcount = new int;
    *_refcount = 1;
    _basesocket = new Basesocket;
 
    #ifdef SOCKET_DEBUG
   debugmsg("Socket: created fresh, " << description() << '\n');
    #endif
}
