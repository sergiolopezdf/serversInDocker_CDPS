#include "socket"

Socket::Socket(int f) {
    _refcount = new int;
    *_refcount = 1;
    _basesocket = new Basesocket(f);

    #ifdef SOCKET_DEBUG
    debugmsg("Socket: created with fd, " << description() << '\n');
    #endif
}
