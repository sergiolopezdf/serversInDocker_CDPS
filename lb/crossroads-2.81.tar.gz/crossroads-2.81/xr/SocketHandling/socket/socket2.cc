#include "socket"

Socket::Socket(Socket const &other) {
    _refcount = other._refcount;
    _basesocket = other._basesocket;
    (*_refcount)++;

    #ifdef SOCKET_DEBUG
    debugmsg("Socket: created copy, " << description() << '\n');
    #endif
}
