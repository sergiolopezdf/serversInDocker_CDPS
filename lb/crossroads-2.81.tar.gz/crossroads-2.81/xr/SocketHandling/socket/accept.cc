#include "socket"

Socket Socket::accept() {
    // Try to accept the client connection (or throw up)
    Basesocket *client = _basesocket->accept();

    // Got a connection. Create a new smartsocket and return it.
    return Socket(client);
}
    
