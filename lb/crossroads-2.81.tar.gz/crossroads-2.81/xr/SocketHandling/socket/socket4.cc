#include "socket"

Socket::Socket(Basesocket *b) {
    _refcount = new int;
    *_refcount = 1;
    _basesocket = b;

    #ifdef SOCKET_DEBUG
    debugmsg("Socket: created with basesocket, " << description() << '\n');
    #endif
}
