#include "socket"

Socket::~Socket() {
    #ifdef SOCKET_DEBUG
    if (*_refcount == 1) {
	debugmsg("Socket: discarding " << description() << '\n');
    } else {
	debugmsg("Socket: subtracting " << description() << '\n');
    }
    #endif
    
    (*_refcount)--;
    if (! *_refcount) {
	delete _refcount;
	delete _basesocket;
    }
}
