#include "socket"

string Socket::description() {
    ostringstream o;

    o << "refcount:" << *_refcount << ", base:" << _basesocket;
    return o.str();
}
