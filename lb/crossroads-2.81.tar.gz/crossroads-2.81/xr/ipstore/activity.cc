#include "ipstore"

void IPStore::activity(struct in_addr clientip, unsigned curbackend) {
    if (!onoff)
	return;

    msg("Logging activity for back end " << curbackend << 
	" from " << inet2string(clientip) << '\n');

    int lock;
    
    mutex_lock(&lock);
    store[clientip].targetbackend = (int)curbackend;
    store[clientip].lastaccess = time(0);
    mutex_unlock(&lock);
}
    
