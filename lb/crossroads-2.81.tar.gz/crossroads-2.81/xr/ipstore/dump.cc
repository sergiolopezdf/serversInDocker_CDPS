#include "ipstore"

void IPStore::dump() {
    if (!config.debug())
	return;

    debugmsg("IPStore dump:\n");
    for (StoreMap::iterator iter = store.begin();
	 iter != store.end();
	 iter++) {
	Timestamp tm((*iter).second.lastaccess);
	ostringstream o;
	o << "Client IP " << inet2string(iter->first) << " on "
	  << tm.desc() << " to back end " << (*iter).second.targetbackend
	  << '\n';
	debugmsg(o.str());
    }
}
