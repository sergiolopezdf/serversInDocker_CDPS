#include "ipstore"

void IPStore::clear(struct in_addr clientip) {
    debugmsg("Erasing IP entry of " << inet2string(clientip) << '\n');

    static int lock;
    
    mutex_lock(&lock);
    store.erase(clientip);
    mutex_unlock(&lock);
}
