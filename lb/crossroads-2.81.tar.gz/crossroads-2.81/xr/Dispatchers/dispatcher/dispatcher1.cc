#include "dispatcher"

Dispatcher::Dispatcher(Socket &clientsock): 
    Thread(), target_backend(-1), client_fd(clientsock),
    backend_fd(-1), algo(0), target_list() {

    start_dispatcher();
}
