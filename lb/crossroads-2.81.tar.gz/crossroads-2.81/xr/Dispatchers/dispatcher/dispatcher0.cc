#include "dispatcher"

Dispatcher::~Dispatcher() {
    delete algo;
    debugmsg ("Dispatcher finished\n");
}
