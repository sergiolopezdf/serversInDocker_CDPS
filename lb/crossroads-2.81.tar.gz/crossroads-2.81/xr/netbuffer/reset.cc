#include "netbuffer"

void Netbuffer::reset() {
    debugmsg("Netbuffer: resetting\n");
    buf_sz = 0;
}
