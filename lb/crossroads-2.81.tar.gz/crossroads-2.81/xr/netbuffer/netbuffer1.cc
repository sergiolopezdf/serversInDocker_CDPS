#include "netbuffer"

Netbuffer::Netbuffer(): buf_data(0), buf_sz(0), buf_alloced(0) {
    debugmsg("Netbuffer: creating zero size buffer\n");
}
