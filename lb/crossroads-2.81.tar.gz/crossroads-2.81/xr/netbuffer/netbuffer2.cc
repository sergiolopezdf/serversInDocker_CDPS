#include "netbuffer"

Netbuffer::Netbuffer (Netbuffer const &other) {
    copy (other);
}
