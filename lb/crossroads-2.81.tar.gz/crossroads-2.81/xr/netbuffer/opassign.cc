#include "netbuffer"

Netbuffer const &Netbuffer::operator= (Netbuffer const &other) {
    debugmsg("Netbuffer: copying other\n");
    if (this != &other) {
	destroy();
	copy (other);
    }
    return (*this);
}
