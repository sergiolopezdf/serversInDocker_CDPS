#include "netbuffer"

string Netbuffer::printable() const {
    string ret;

    for (unsigned i = 0; i < buf_sz; i++)
	ret += printable(buf_data[i]);
    return ret;
}
