#include "netbuffer"

void Netbuffer::setstring(string const &s) {
    debugmsg("Netbuffer: setting to string\n");
    
    destroy();
    check_space(s.size() + 1);    
    buf_sz = s.size();	
    memcpy (buf_data, s.c_str(), buf_sz);
    buf_data[buf_sz] = 0;
}
