#include "netbuffer"

Netbuffer::Netbuffer (string const &s):
    buf_data(0), buf_sz(0), buf_alloced(0)  {
    setstring(s);
}
