#include "netbuffer"

char Netbuffer::charat(unsigned index) const {
    PROFILE("Netbuffer::charat");
    
    if (index >= buf_sz)
	return (0);
    return buf_data[index];
}
