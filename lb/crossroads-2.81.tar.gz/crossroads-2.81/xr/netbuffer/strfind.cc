#include "netbuffer"

unsigned Netbuffer::strfind(char const *s) const {
    PROFILE("Netbuffer::strfind");

    if (!buf_sz)
	return (0);

    char *cp = strnstr(buf_data, s, buf_sz);
    if (cp)
	return (cp - buf_data);
    
    return (0);
}
    
