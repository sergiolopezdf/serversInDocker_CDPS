#include "netbuffer"

unsigned Netbuffer::charfind(char ch, unsigned start) const {
    PROFILE("Netbuffer::charfind");

    if (buf_sz <= start)
	return 0;

    char *cp = (char*)memchr(buf_data + start, ch, buf_sz);
    if (!cp)
	return (0);
    return (cp - buf_data);
}
