#include "netbuffer"

void Netbuffer::destroy() {
    if (buf_alloced)
	debugmsg("Netbuffer: destroying " << buf_alloced << " bytes\n");
    free(buf_data);
    buf_data 	= 0;
    buf_sz 	= 0;
    buf_alloced = 0;
}
