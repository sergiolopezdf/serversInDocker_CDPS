#include "netbuffer"

Netbuffer::~Netbuffer() {
    destroy();
}
