#include "netbuffer"

string Netbuffer::stringat(unsigned index, unsigned len) {
    string ret;
    for (unsigned i = index; i < index + len; i++) {
	if (i >= buf_sz)
	    break;
	ret += buf_data[i];
    }
    return ret;
}
