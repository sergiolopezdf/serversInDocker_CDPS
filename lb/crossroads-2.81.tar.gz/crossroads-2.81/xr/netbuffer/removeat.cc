#include "netbuffer"

bool Netbuffer::removeat(unsigned index, unsigned len) {
    if (index >= buf_sz)
	return false;

    if (index + len >= buf_sz)
	buf_sz = index;
    else {
	memmove (buf_data + index, buf_data + index + len,
		 buf_sz - index - len);
	buf_sz -= len;
    }
    return true;
}
