#include "netbuffer"

bool Netbuffer::setchar(unsigned offset, char ch) {
    PROFILE("Netbuffer::setchar");
    if (offset >= buf_sz)
	return false;
    buf_data[offset] = ch;
    return true;
}
