#include "servertype"

#include "error/error"

void Servertype::type (string id) {
    if (id == "tcp")
	t = t_tcp;
    else if (id == "http")
	t = t_http;
    else
	throw Error("Bad server type '" + id +
		    "', supported are 'tcp' or 'http'");
}
