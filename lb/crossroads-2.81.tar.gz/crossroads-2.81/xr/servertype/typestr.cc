#include "servertype"

#include "error/error"

string Servertype::typestr() const {
    if (t == t_tcp)
	return ("tcp");
    else if (t == t_http)
	return ("http");
    else
	throw Error("Server type unknown in Servertype::typestr");
}
